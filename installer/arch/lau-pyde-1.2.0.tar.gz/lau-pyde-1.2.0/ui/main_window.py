from pathlib import Path
import json
import os
import re
import subprocess
import sys
import time
from typing import Optional

from PySide6.QtCore import Qt, QSettings, QThread, QTimer, QUrl, QSize, QEvent, Signal
from PySide6.QtCore import QTimer
from PySide6.QtGui import QAction, QActionGroup, QKeySequence, QTextCursor, QTextCharFormat, QColor, QTextCharFormat as _QTextCharFormat, QImage, QTextDocument
from PySide6.QtWidgets import QTextEdit
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest
from PySide6.QtWidgets import (
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QGridLayout,
    QInputDialog,
    QDialogButtonBox,
    QTextBrowser,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QLineEdit,
    QTabWidget,
    QTabBar,
    QToolButton,
    QFrame,
    QVBoxLayout,
    QWidget,
    QStackedWidget,
    
)
from PySide6.QtGui import QShortcut, QDesktopServices, QIcon
from ui.panel_icons import panel_icon, ICON_SIZE
from ui.file_icons import LauPydeFileIconProvider

from core.file_manager import read_file, write_file
from core.file_manager import (
    write_recovery,
    list_recoveries,
    read_recovery,
    remove_recovery,
    remove_recovery_for_path,
)
from core.runner import PythonRunner
from ui.editor import CodeEditor
from ui.explorer import FileExplorer
from ui.inline_output import InlineInputOutput
from ui.terminal import TerminalPanel
from core.update_checker import RELEASE_PAGE, UpdateWorker, compare_versions, current_platform, select_download_url

APP_NAME = "Lau-PyDE"
APP_VERSION = "1.2.0"
SETTINGS_ORGANIZATION = "Lau-PyDE"

RECENT_PROJECT_FILE = Path.home() / ".lau_pyde_recent.json"

MARKDOWN_PREVIEW_STYLESHEET = """
body {
    color: #d7dce2;
    font-family: "Noto Sans", "DejaVu Sans", sans-serif;
    font-size: 14px;
}
h1, h2, h3, h4, h5, h6 {
    color: #f0f3f6;
    margin-top: 24px;
    margin-bottom: 12px;
}
h1 {
    font-size: 30px;
    border-bottom: 1px solid #414a54;
    padding-bottom: 8px;
}
h2 {
    font-size: 23px;
    border-bottom: 1px solid #343c45;
    padding-bottom: 6px;
}
h3 { font-size: 18px; }
p { margin-top: 8px; margin-bottom: 14px; }
a { color: #69b8ff; text-decoration: none; }
a:hover { text-decoration: underline; }
blockquote {
    color: #b6c0cb;
    background-color: #252b31;
    border-left: 3px solid #4da99b;
    margin-left: 0;
    padding: 8px 14px;
}
code {
    color: #e8c782;
    background-color: #292e34;
    font-family: "DejaVu Sans Mono", monospace;
    padding: 2px 4px;
}
pre {
    color: #d7dce2;
    background-color: #171a1e;
    border: 1px solid #343c45;
    padding: 12px;
}
pre code { background-color: transparent; padding: 0; }
table {
    border-collapse: collapse;
    margin-top: 12px;
    margin-bottom: 18px;
}
th {
    color: #f0f3f6;
    background-color: #303840;
    font-weight: bold;
}
th, td {
    border: 1px solid #48525d;
    padding: 7px 10px;
}
tr:nth-child(even) { background-color: #24292f; }
hr { color: #414a54; background-color: #414a54; height: 1px; }
img { vertical-align: middle; margin: 4px 6px 4px 0; }
li { margin-top: 3px; margin-bottom: 3px; }
"""


class MarkdownPreviewBrowser(QTextBrowser):
    image_loaded = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._network = QNetworkAccessManager(self)
        self._pending_image_urls: set[str] = set()
        self._image_cache: dict[str, QImage] = {}
        self.document().setDefaultStyleSheet(MARKDOWN_PREVIEW_STYLESHEET)
        self.document().setDocumentMargin(24)
        self.setOpenLinks(True)
        self.setOpenExternalLinks(True)

    def set_markdown_source(self, markdown: str, source_path: str | None) -> None:
        if source_path:
            source_directory = Path(source_path).expanduser().resolve().parent
            self.setSearchPaths([str(source_directory)])
            self.document().setBaseUrl(QUrl.fromLocalFile(str(source_directory) + "/"))
        else:
            self.setSearchPaths([])
            self.document().setBaseUrl(QUrl())
        self.document().setDefaultStyleSheet(MARKDOWN_PREVIEW_STYLESHEET)
        self.setMarkdown(markdown)

    def loadResource(self, resource_type, name):
        url = name if isinstance(name, QUrl) else QUrl(str(name))
        if resource_type == QTextDocument.ImageResource and url.scheme().lower() in {"http", "https"}:
            key = url.toString()
            if key in self._image_cache:
                return self._image_cache[key]
            if key not in self._pending_image_urls:
                self._pending_image_urls.add(key)
                reply = self._network.get(QNetworkRequest(url))
                reply.finished.connect(lambda reply=reply, key=key, url=url: self._finish_image_request(reply, key, url))
            return QImage()
        return super().loadResource(resource_type, name)

    def _finish_image_request(self, reply, key: str, url: QUrl) -> None:
        self._pending_image_urls.discard(key)
        if reply.error() == reply.NetworkError.NoError:
            image_data = bytes(reply.readAll())
            if len(image_data) <= 8 * 1024 * 1024:
                image = QImage.fromData(image_data)
                if not image.isNull():
                    self._image_cache[key] = image
                    self.document().addResource(QTextDocument.ImageResource, url, image)
                    self.document().markContentsDirty(0, self.document().characterCount())
                    self.viewport().update()
                    self.image_loaded.emit(key)
        reply.deleteLater()

DARK_STYLESHEET = """

QWidget {
    background-color: #1e1e1e;
    color: #d4d4d4;
    font-size: 13px
}

QPlainTextEdit, QLineEdit, QTreeView {
    background-color: #1e1e1e;
    color: #d4d4d4;
    border: 1px solid #3c3c3c;
}

QMenuBar {
    background-color: #2d2d2d;
}

QMenuBar::item:selected {
    background-color: #3c3c3c;
}

QMenu {
    background-color: #2d2d2d;
    border: 1px solid #3c3c3c;
}

QMenu::item:selected {
    background-color: #3c3c3c;
}

QTabWidget::pane {
    border: 1px solid #3c3c3c;
}

QTabBar::tab {
    background-color: #2d2d2d;
    padding: 6px 12px;
}

QTabBar::tab:selected {
    background-color: #1e1e1e;
}

QStatusBar {
    background-color: #2d2d2d;
}

QSplitter::handle {
    background-color: #3c3c3c;
}

QScrollBar:vertical,
QScrollBar:horizontal {
    background: transparent;
    border: none;
    margin: 0;
}

QScrollBar:vertical {
    width: 12px;
}

QScrollBar:horizontal {
    height: 12px;
}

QScrollBar::handle:vertical,
QScrollBar::handle:horizontal {
    background: #3a3d4a;
    border: 1px solid #4b4f5d;
    border-radius: 6px;
    min-height: 18px;
    min-width: 18px;
}

QScrollBar::handle:vertical:hover,
QScrollBar::handle:horizontal:hover {
    background: #4e5568;
}

QScrollBar::handle:vertical:pressed,
QScrollBar::handle:horizontal:pressed {
    background: #5c637c;
}

QScrollBar::add-line,
QScrollBar::sub-line,
QScrollBar::up-arrow,
QScrollBar::down-arrow,
QScrollBar::left-arrow,
QScrollBar::right-arrow {
    background: none;
    border: none;
    width: 0px;
    height: 0px;
}

QScrollBar::add-page,
QScrollBar::sub-page {
    background: transparent;
}

"""

class MainWindow(QMainWindow):
    """The PyDE main window: menu bar + explorer + editor + output/terminal."""

    def __init__(self):
        super().__init__()

        # which file is currently open, and which folder is the workspace
        # (used by the explorer, the terminal, and as the working
        # directory when running a file).
        self._current_file_path: Optional[str] = None
        self._current_folder: Optional[str] = None
        self._file_icon_provider = LauPydeFileIconProvider()
        self._maximized_pane: Optional[str] = None
        self._explorer_minimized = False
        self._bottom_minimized = False
        self._project_root_permission_granted = False
        self._update_thread = None
        self._update_worker = None
        self._update_manual = False
        self._last_update_version = None

        self.resize(1200, 800)

        self._build_widgets()
        self._build_layout()
        self._build_menu_and_shortcuts()
        self._enable_folder_drop_targets()

        # autosave timer
        self._autosave_timer = QTimer(self)
        self._autosave_timer.setInterval(10 * 1000)
        self._autosave_timer.timeout.connect(self._maybe_autosave)
        self._autosave_timer.start()
        self._autosave_debounce_timer = QTimer(self)
        self._autosave_debounce_timer.setSingleShot(True)
        self._autosave_debounce_timer.setInterval(300)
        self._autosave_debounce_timer.timeout.connect(self._autosave_current_file)
        self.editor.textChanged.connect(self._schedule_autosave)

        # Startup recovery prompts are intentionally disabled: Lau-PyDE now
        # auto-saves the current editor content when a file is run, rather than
        # restoring stale backups at launch.
        self.statusBar().showMessage("Ready")
        self._update_title()
        QTimer.singleShot(1500, self._startup_update_check)

    def _set_key_shortcuts_visible(self, visible: bool) -> None:
        visible = bool(visible)
        if self.explorer._commands_section.isHidden() == visible:
            self.explorer._toggle_commands_section()
        settings = QSettings(SETTINGS_ORGANIZATION, APP_NAME)
        settings.setValue("show_key_shortcuts", visible)
        settings.sync()
        if hasattr(self, "_show_commands_list_action"):
            self._show_commands_list_action.setChecked(visible)

    def _welcome_section_heading(self, title: str) -> QWidget:
        heading = QWidget()
        row = QHBoxLayout(heading)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(12)
        label = QLabel(title)
        label.setStyleSheet(
            "font-size: 11px; font-weight: bold; color: #aebdce; letter-spacing: 1px;"
        )
        rule = QFrame()
        rule.setFrameShape(QFrame.HLine)
        rule.setFixedHeight(1)
        rule.setStyleSheet("color: #343c45; background: #343c45; border: none;")
        row.addWidget(label)
        row.addWidget(rule, 1)
        return heading

    def _recent_file_paths(self) -> list[str]:
        settings = QSettings(SETTINGS_ORGANIZATION, APP_NAME)
        stored_paths = settings.value("recent_files", [], type=list)
        recent = []
        seen = set()
        for stored_path in stored_paths:
            try:
                path = Path(str(stored_path)).expanduser().resolve()
            except (OSError, RuntimeError):
                continue
            key = str(path)
            if key in seen or not path.is_file():
                continue
            seen.add(key)
            recent.append(key)
            if len(recent) == 5:
                break
        if recent != stored_paths:
            settings.setValue("recent_files", recent)
        return recent

    def _record_recent_file(self, path: str) -> None:
        try:
            resolved_path = str(Path(path).expanduser().resolve())
        except (OSError, RuntimeError):
            return
        if not Path(resolved_path).is_file():
            return
        recent = [item for item in self._recent_file_paths() if item != resolved_path]
        recent.insert(0, resolved_path)
        settings = QSettings(SETTINGS_ORGANIZATION, APP_NAME)
        settings.setValue("recent_files", recent[:5])
        settings.sync()
        self._refresh_welcome_recent_files()

    def _remove_recent_file(self, path: str) -> None:
        settings = QSettings(SETTINGS_ORGANIZATION, APP_NAME)
        settings.setValue(
            "recent_files",
            [item for item in self._recent_file_paths() if item != path],
        )
        settings.sync()
        self._refresh_welcome_recent_files()

    def _open_recent_file(self, path: str) -> None:
        if not Path(path).is_file():
            self._remove_recent_file(path)
            QMessageBox.information(
                self,
                APP_NAME,
                f"This recent file no longer exists and was removed from the list:\n{path}",
            )
            return
        self.open_file(path)

    def _refresh_welcome_recent_files(self) -> None:
        if not hasattr(self, "_welcome_recent_rows"):
            return
        while self._welcome_recent_rows.count():
            item = self._welcome_recent_rows.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        paths = self._recent_file_paths()
        self._welcome_recent_section.setVisible(bool(paths))
        for path in paths:
            file_path = Path(path)
            row_widget = QWidget()
            row = QHBoxLayout(row_widget)
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(12)
            open_button = QToolButton()
            open_button.setObjectName("recentFileButton")
            open_button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            open_button.setIcon(self._file_icon_provider.icon_from_path(path))
            open_button.setText(file_path.name)
            open_button.setToolTip(path)
            open_button.setCursor(Qt.PointingHandCursor)
            open_button.setStyleSheet(
                "QToolButton { color: #d7dce2; border: none; text-align: left; padding: 5px 2px; }"
                "QToolButton:hover { color: #75baff; background: #252b31; }"
            )
            open_button.clicked.connect(
                lambda _checked=False, recent_path=path: self._open_recent_file(recent_path)
            )
            parent = file_path.parent
            try:
                relative_parent = parent.relative_to(Path.home())
                parent_text = "~/" + relative_parent.as_posix() if str(relative_parent) != "." else "~"
            except ValueError:
                parent_text = str(parent)
            parent_label = QLabel(parent_text)
            parent_label.setStyleSheet("font-size: 12px; color: #738295;")
            row.addWidget(open_button)
            row.addWidget(parent_label, 1)
            self._welcome_recent_rows.addWidget(row_widget)

    # main setup
    def _build_widgets(self) -> None:
        self.editor = CodeEditor()
        self.editor.document().modificationChanged.connect(self._on_modification_changed)

        # connect diagnostics_changed signal to update explorer error badge
        try:
            self.editor.diagnostics_changed.connect(self._on_diagnostics_changed)
        except Exception:
            pass

        self._file_label = QLabel("Untitled")
        self._file_label.setStyleSheet(
            "font-size: 12px; font-weight: bold; color: #d4d4d4;"
        )
        self._error_badge = QLabel("")
        self._error_badge.setStyleSheet(
            "font-size: 11px; font-weight: bold; color: #ff6b6b;"
        )

        editor_header = QWidget()
        header_layout = QHBoxLayout(editor_header)
        header_layout.setContentsMargins(10, 6, 10, 6)
        header_layout.addWidget(self._file_label)
        header_layout.addStretch()
        self._markdown_preview_button = QPushButton("Preview")
        self._markdown_preview_button.setToolTip("Toggle Markdown preview")
        self._markdown_preview_button.clicked.connect(self._toggle_markdown_preview)
        self._markdown_preview_button.hide()
        header_layout.addWidget(self._markdown_preview_button)
        header_layout.addWidget(self._error_badge)

        # lightweight in-editor search bar (hidden by default)
        self._search_bar = QWidget()
        sb_layout = QHBoxLayout(self._search_bar)
        sb_layout.setContentsMargins(6, 4, 6, 4)
        self._search_input = QLineEdit()
        self._search_input.setPlaceholderText("Find in file (Ctrl+F)")
        self._search_prev = QPushButton("▲")
        self._search_next = QPushButton("▼")
        self._search_count = QLabel("")
        self._search_close = QPushButton("✕")
        for w in (self._search_prev, self._search_next, self._search_close):
            w.setFixedWidth(28)
            w.setCursor(Qt.PointingHandCursor)
            w.setStyleSheet("border: none;")

        sb_layout.addWidget(self._search_input)
        sb_layout.addWidget(self._search_prev)
        sb_layout.addWidget(self._search_next)
        sb_layout.addWidget(self._search_count)
        sb_layout.addWidget(self._search_close)
        self._search_bar.hide()

        self._editor_container = QWidget()
        editor_container_layout = QVBoxLayout(self._editor_container)
        editor_container_layout.setContentsMargins(0, 0, 0, 0)
        editor_container_layout.setSpacing(0)
        self._file_tab_bar = QTabBar()
        self._file_tab_bar.setDocumentMode(True)
        self._file_tab_bar.setExpanding(False)
        self._file_tab_bar.setMovable(True)
        self._file_tab_bar.setTabsClosable(False)
        self._file_tab_bar.currentChanged.connect(self._on_file_tab_changed)
        self._file_tab_bar.hide()
        editor_container_layout.addWidget(self._file_tab_bar)
        editor_container_layout.addWidget(editor_header)
        editor_container_layout.addWidget(self._search_bar)
        self._markdown_preview = MarkdownPreviewBrowser()
        self._editor_content = QStackedWidget()
        self._editor_content.addWidget(self.editor)
        self._editor_content.addWidget(self._markdown_preview)
        self.editor.textChanged.connect(self._refresh_markdown_preview)
        editor_container_layout.addWidget(self._editor_content)

        self._editor_stack = QStackedWidget()

        self._welcome_widget = QWidget()
        welcome_layout = QVBoxLayout(self._welcome_widget)
        welcome_layout.setContentsMargins(24, 24, 24, 24)
        welcome_layout.addStretch(1)

        welcome_content = QWidget()
        welcome_content.setObjectName("welcomeContent")
        welcome_content.setMaximumWidth(560)
        content_layout = QVBoxLayout(welcome_content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        welcome_title = QLabel("Welcome to Lau-PyDE")
        welcome_title.setAlignment(Qt.AlignCenter)
        welcome_title.setStyleSheet(
            "font-size: 32px;"
            "font-weight: bold;"
            "color: #f0f3f6;"
        )
        welcome_subtitle = QLabel("A lightweight environment for Python development.")
        welcome_subtitle.setAlignment(Qt.AlignCenter)
        welcome_subtitle.setStyleSheet("font-size: 16px; color: #aebdce; margin-top: 12px;")
        content_layout.addWidget(welcome_title)
        content_layout.addWidget(welcome_subtitle)

        content_layout.addSpacing(42)
        content_layout.addWidget(self._welcome_section_heading("QUICK ACTIONS"))
        actions_grid = QGridLayout()
        actions_grid.setContentsMargins(0, 12, 0, 0)
        actions_grid.setHorizontalSpacing(24)
        actions_grid.setVerticalSpacing(8)
        self._welcome_action_buttons = {}
        for row, (action_key, shortcut, label) in enumerate((
            ("new", "Ctrl+N", "New File"),
            ("open", "Ctrl+O", "Open File"),
            ("folder", "Ctrl+L", "Open Folder"),
        )):
            key_label = QLabel(shortcut)
            key_label.setAlignment(Qt.AlignCenter)
            key_label.setStyleSheet(
                "QLabel { color: #c4cfdb; background: #2a3038; border: 1px solid #3b444f; "
                "border-radius: 4px; padding: 5px 8px; font-family: monospace; font-size: 12px; }"
            )
            action_button = QPushButton(label)
            action_button.setObjectName(f"welcome_{action_key}_action")
            action_button.setFlat(True)
            action_button.setCursor(Qt.PointingHandCursor)
            action_button.setStyleSheet(
                "QPushButton { color: #d7dce2; text-align: left; padding: 5px 4px; }"
                "QPushButton:hover { color: #75baff; background: #252b31; }"
            )
            self._welcome_action_buttons[action_key] = action_button
            actions_grid.addWidget(key_label, row, 0, Qt.AlignLeft)
            actions_grid.addWidget(action_button, row, 1)
        actions_grid.setColumnStretch(1, 1)
        content_layout.addLayout(actions_grid)

        content_layout.addSpacing(36)
        self._welcome_recent_section = QWidget()
        recent_layout = QVBoxLayout(self._welcome_recent_section)
        recent_layout.setContentsMargins(0, 0, 0, 0)
        recent_layout.setSpacing(0)
        recent_layout.addWidget(self._welcome_section_heading("RECENT FILES"))
        self._welcome_recent_rows = QVBoxLayout()
        self._welcome_recent_rows.setContentsMargins(0, 10, 0, 0)
        self._welcome_recent_rows.setSpacing(4)
        recent_layout.addLayout(self._welcome_recent_rows)
        content_layout.addWidget(self._welcome_recent_section)

        self._welcome_footer = QLabel(
            f"Lau-PyDE   ·   Python Development Environment   ·   v{APP_VERSION}"
        )
        self._welcome_footer.setAlignment(Qt.AlignCenter)
        self._welcome_footer.setStyleSheet("font-size: 11px; color: #738295; margin-top: 34px;")
        content_layout.addWidget(self._welcome_footer)

        welcome_layout.addWidget(welcome_content, 0, Qt.AlignHCenter)
        welcome_layout.addStretch(1)
        self._editor_stack.addWidget(self._welcome_widget)
        self._editor_stack.addWidget(self._editor_container)
        self._editor_stack.setCurrentWidget(self._welcome_widget)
        self._refresh_welcome_recent_files()

        # self.explorer = FileExplorer()
        # self.load_recent_project()
        # self.explorer.file_double_clicked.connect(self.open_file)
        self.explorer = FileExplorer()
        self.explorer.set_root_folder(None)

        # connect search controls
        self._search_input.textChanged.connect(self._on_search_text_changed)
        self._search_prev.clicked.connect(lambda: self._search_move(-1))
        self._search_next.clicked.connect(lambda: self._search_move(1))
        self._search_close.clicked.connect(self._close_search)
        # Ctrl+F shortcut
        try:
            QShortcut(QKeySequence("Ctrl+F"), self, activated=self._open_search)
        except Exception:
            pass

        # internal search state
        self._search_matches: list[QTextCursor] = []
        self._search_index: int = -1

        self.explorer.file_double_clicked.connect(self.open_file)

        self.output_panel = InlineInputOutput()
        self.output_panel.input_submitted.connect(self.send_input)
        self._active_prompt = ""
        self._output_line_tail = ""

        self.terminal_panel = TerminalPanel()
        self.terminal_panel.minimize_requested.connect(self._minimize_bottom_panel)
        self.terminal_panel.maximize_requested.connect(
            lambda: self._maximize_pane("terminal")
        )

        # Restore the recent workspace only after the terminal exists,
        # because restoration also sets its working directory.
        self.load_recent_project()

        self.explorer.minimize_requested.connect(self._minimize_explorer)
        self.explorer.maximize_requested.connect(lambda: self._maximize_pane("explorer"))

        # populate explorer commands list from available actions
        try:
            # gather actionable shortcuts from the menu actions that are enabled
            actions = [
                ("New File", self.findChild(QAction, "")),
            ]
        except Exception:
            actions = []

        # populate_commands will be called after menus are built

        self._runner = PythonRunner()
        self._runner.output_ready.connect(self._append_output)
        self._runner.finished.connect(self._on_run_finished)

    def _on_diagnostics_changed(self, count: int) -> None:
        """Handle diagnostics_changed signals from the editor by updating
        the explorer's error count for the currently open file and the UI."""
        try:
            if not self._current_file_path:
                return

            # update explorer badge/count
            try:
                self.explorer.set_error_count(self._current_file_path, count)
            except Exception:
                pass

            # update small error badge in editor header and window title
            try:
                if count:
                    self._error_badge.setText(f"Errors: {count}")
                else:
                    self._error_badge.setText("")
            except Exception:
                pass

            # refresh title/status
            try:
                self._update_title()
            except Exception:
                pass
        except Exception:
            pass

    def send_input(self, text: str) -> None:
        if not self._runner.is_running():
            return
            
        # self.output_panel.insertPlainText(text)
        self.output_panel.stop_input()
        self._active_prompt = ""

        self._runner.write_input(text + "\n")

    def _build_layout(self) -> None:
        output_container = QWidget()
        output_layout = QVBoxLayout(output_container)
        output_layout.setContentsMargins(4, 4, 4, 4)

        output_title = QWidget()
        output_title.setFixedHeight(32)
        output_title_layout = QHBoxLayout(output_title)
        output_title_layout.setContentsMargins(4, 0, 4, 0)
        output_title_layout.setSpacing(0)
        output_title_layout.addWidget(QLabel("Output"))
        output_title_layout.addStretch()

        # replace textual Stop with a compact stop icon button
        self._stop_running_button = QPushButton()
        self._stop_running_button.setToolTip("Run the current Python file")
        self._stop_running_button.setEnabled(True)
        self._stop_running_button.clicked.connect(self._run_or_stop)
        self._stop_running_button.setFixedSize(32, 24)
        self._stop_running_button.setIcon(panel_icon("play"))
        self._stop_running_button.setIconSize(ICON_SIZE)
        button_style = (
            "QPushButton { border: none; padding: 0px; margin: 0px; "
            "font-family: DejaVu Sans, Segoe UI, sans-serif; font-size: 12px; "
            "font-weight: normal; }"
        )
        self._stop_running_button.setStyleSheet(button_style)
        self._stop_running_button.setCursor(Qt.PointingHandCursor)
        self._stop_running_button.setContentsMargins(0, 0, 0, 0)
        self._stop_running_button.setCursor(Qt.PointingHandCursor)
        output_title_layout.addWidget(self._stop_running_button)

        output_minimize_button = QPushButton()
        output_maximize_button = QPushButton()
        output_minimize_button.setToolTip("Minimize output and terminal")
        output_maximize_button.setToolTip("Maximize or restore output")
        output_minimize_button.setFixedSize(32, 24)
        output_minimize_button.setIcon(panel_icon("minimize"))
        output_minimize_button.setIconSize(ICON_SIZE)
        output_maximize_button.setFixedSize(32, 24)
        output_maximize_button.setIcon(panel_icon("maximize"))
        output_maximize_button.setIconSize(ICON_SIZE)
        output_minimize_button.clicked.connect(self._minimize_bottom_panel)
        output_maximize_button.clicked.connect(lambda: self._maximize_pane("output"))
        # remove button borders for a sleeker look
        button_style = (
            "QPushButton { border: none; padding: 0px; margin: 0px; "
            "font-family: DejaVu Sans, Segoe UI, sans-serif; font-size: 12px; "
            "font-weight: normal; }"
        )
        output_minimize_button.setStyleSheet(button_style)
        output_minimize_button.setCursor(Qt.PointingHandCursor)
        output_minimize_button.setContentsMargins(0, 0, 0, 0)
        output_maximize_button.setStyleSheet(button_style)
        output_maximize_button.setCursor(Qt.PointingHandCursor)
        output_maximize_button.setContentsMargins(0, 0, 0, 0)
        output_title_layout.addWidget(output_minimize_button)
        output_title_layout.addWidget(output_maximize_button)

        output_layout.addWidget(output_title)
        output_layout.addWidget(self.output_panel)

        # for loop approach para sa pointer na cursor
        for pointer in (
            output_minimize_button,
            output_maximize_button,
        ):
            pointer.setCursor(Qt.PointingHandCursor)
        
        # orientation toggle: switch between bottom (horizontal) and right (vertical)
        self._output_orientation = "horizontal"  # or 'vertical'
        self._output_orientation_button = QPushButton()
        self._output_orientation_button.setToolTip("Move output to the right")
        self._output_orientation_button.setFixedSize(32, 24)
        self._output_orientation_button.setIcon(panel_icon("orient-right"))
        self._output_orientation_button.setIconSize(ICON_SIZE)
        self._output_orientation_button.setStyleSheet(button_style)
        self._output_orientation_button.setCursor(Qt.PointingHandCursor)
        self._output_orientation_button.setContentsMargins(0, 0, 0, 0)
        self._output_orientation_button.setStyleSheet(button_style)
        self._output_orientation_button.setCursor(Qt.PointingHandCursor)
        self._output_orientation_button.clicked.connect(self._toggle_output_orientation)
        output_title_layout.addWidget(self._output_orientation_button)

        bottom_tabs = QTabWidget()
        bottom_tabs.addTab(output_container, "Output")
        bottom_tabs.addTab(self.terminal_panel, "Terminal")
        self._bottom_tabs = bottom_tabs
        self._output_container = output_container

        # single splitter: editor stack and Output/Terminal tabs.
        # We'll toggle its orientation between Qt.Vertical (output bottom)
        # and Qt.Horizontal (output right) when the user clicks the control.
        self._editor_and_output = QSplitter(Qt.Vertical)
        self._editor_and_output.addWidget(self._editor_stack)
        self._editor_and_output.addWidget(bottom_tabs)
        self._editor_and_output.setStretchFactor(0, 3)
        self._editor_and_output.setStretchFactor(1, 1)

        # horizontal splitter: explorer sidebar on the left, everything
        # else on the right. QSplitter lets the user drag to resize.
        main_splitter = QSplitter(Qt.Horizontal)
        main_splitter.addWidget(self.explorer)
        # add current active editor/output splitter
        main_splitter.addWidget(self._editor_and_output)
        main_splitter.setStretchFactor(0, 0)
        main_splitter.setStretchFactor(1, 1)
        main_splitter.setSizes([220, 980])
        self._main_splitter = main_splitter

        self.setCentralWidget(main_splitter)
        # ensure initial layout visibility and sizes are applied
        try:
            self._restore_layout()
        except Exception:
            pass

    # Search helpers
    def _open_search(self) -> None:
        self._search_bar.show()
        self._search_input.setFocus()

    def _close_search(self) -> None:
        self._search_bar.hide()
        self._search_input.clear()
        self._clear_search_highlights()

    def _on_search_text_changed(self, text: str) -> None:
        self._find_all_in_editor(text)

    def _find_all_in_editor(self, pattern: str) -> None:
        self._clear_search_highlights()
        if not pattern:
            self._search_count.setText("")
            return

        doc = self.editor.document()
        cursor = doc.find(pattern)
        matches = []
        while not cursor.isNull():
            # clone the cursor
            c = QTextCursor(cursor)
            matches.append(c)
            cursor = doc.find(pattern, cursor)

        self._search_matches = matches
        self._search_index = 0 if matches else -1
        self._search_count.setText(f"{len(matches)}")
        # highlight all matches and select the first
        for c in matches:
            self._highlight_range(c.selectionStart(), c.selectionEnd())

        if matches:
            self._select_search_index(0)

    def _highlight_range(self, start: int, end: int) -> None:
        extra = QTextEdit.ExtraSelection()
        fmt = QTextCharFormat()
        fmt.setBackground(QColor("#44475a"))
        extra.format = fmt
        cur = self.editor.textCursor()
        cur.setPosition(start)
        cur.setPosition(end, QTextCursor.KeepAnchor)
        extra.cursor = cur
        sels = self.editor.extraSelections()
        sels.append(extra)
        self.editor.setExtraSelections(sels)

    def _clear_search_highlights(self) -> None:
        self.editor.setExtraSelections([])

    def _select_search_index(self, idx: int) -> None:
        if not self._search_matches:
            return
        idx = idx % len(self._search_matches)
        self._search_index = idx
        cur = self._search_matches[idx]
        self.editor.setTextCursor(cur)
        # ensure visible
        self.editor.centerCursor()

    def _search_move(self, delta: int) -> None:
        if not self._search_matches:
            return
        self._search_index = (self._search_index + delta) % len(self._search_matches)
        self._select_search_index(self._search_index)

    def _build_menu_and_shortcuts(self) -> None:
        """
        Build the menu bar.

        Each menu item is a QAction, which bundles together a label,
        a keyboard shortcut, and what happens when it's triggered (its
        `triggered` signal). The same QAction could also be reused on
        a toolbar, though v0.1 only uses menus.
        """
        menu_bar = self.menuBar()

        # file menu
        file_menu = menu_bar.addMenu("&File")

        new_action = QAction("New File", self)
        self._new_file_action = new_action
        new_action.setShortcut(QKeySequence("Ctrl+N"))
        new_action.triggered.connect(self.new_file)
        file_menu.addAction(new_action)

        new_folder_action = QAction("New Folder", self)
        new_folder_action.setShortcut(QKeySequence("Ctrl+Shift+N"))
        new_folder_action.triggered.connect(self.new_folder)
        file_menu.addAction(new_folder_action)

        open_action = QAction("Open File...", self)
        self._open_file_action = open_action
        open_action.setShortcut(QKeySequence("Ctrl+O"))
        open_action.triggered.connect(self.open_file_dialog)
        file_menu.addAction(open_action)

        open_folder_action = QAction("Open Folder...", self)
        self._open_folder_action = open_folder_action
        open_folder_action.setShortcut(QKeySequence("Ctrl+L"))
        open_folder_action.triggered.connect(self.open_folder_dialog)
        file_menu.addAction(open_folder_action)

        self._welcome_action_buttons["new"].clicked.connect(
            lambda _checked=False: self._new_file_action.trigger()
        )
        self._welcome_action_buttons["open"].clicked.connect(
            lambda _checked=False: self._open_file_action.trigger()
        )
        self._welcome_action_buttons["folder"].clicked.connect(
            lambda _checked=False: self._open_folder_action.trigger()
        )

        close_project_action = QAction("Close Project", self)
        close_project_action.setShortcut(QKeySequence("Ctrl+P"))
        close_project_action.triggered.connect(self.close_project)
        file_menu.addAction(close_project_action)

        file_menu.addSeparator()

        save_action = QAction("Save", self)
        save_action.setShortcut(QKeySequence("Ctrl+S"))
        save_action.triggered.connect(self.save_file)
        file_menu.addAction(save_action)

        save_as_action = QAction("Save As...", self)
        save_as_action.setShortcut(QKeySequence("Ctrl+Shift+S"))
        save_as_action.triggered.connect(self.save_file_as)
        file_menu.addAction(save_as_action)

        file_menu.addSeparator()

        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        exit_action.setShortcut(QKeySequence("Ctrl+Q"))
        file_menu.addAction(exit_action)

        # edit menu
        edit_menu = menu_bar.addMenu("&Edit")

        undo_action = QAction("Undo", self)
        undo_action.setShortcut(QKeySequence.Undo)
        undo_action.setShortcutContext(Qt.ApplicationShortcut)
        undo_action.triggered.connect(lambda: self._edit_action("undo"))
        edit_menu.addAction(undo_action)

        redo_action = QAction("Redo", self)
        redo_action.setShortcut(QKeySequence("Ctrl+Y"))
        redo_action.setShortcutContext(Qt.ApplicationShortcut)
        redo_action.triggered.connect(lambda: self._edit_action("redo"))
        edit_menu.addAction(redo_action)

        edit_menu.addSeparator()

        cut_action = QAction("Cut", self)
        cut_action.setShortcut(QKeySequence.Cut)
        cut_action.setShortcutContext(Qt.ApplicationShortcut)
        cut_action.triggered.connect(lambda: self._edit_action("cut"))
        edit_menu.addAction(cut_action)

        copy_action = QAction("Copy", self)
        copy_action.setShortcut(QKeySequence.Copy)
        copy_action.setShortcutContext(Qt.ApplicationShortcut)
        copy_action.triggered.connect(lambda: self._edit_action("copy"))
        edit_menu.addAction(copy_action)

        paste_action = QAction("Paste", self)
        paste_action.setShortcut(QKeySequence.Paste)
        paste_action.setShortcutContext(Qt.ApplicationShortcut)
        paste_action.triggered.connect(lambda: self._edit_action("paste"))
        edit_menu.addAction(paste_action)

        edit_menu.addSeparator()

        select_all_action = QAction("Select All", self)
        select_all_action.setShortcut(QKeySequence.SelectAll)
        select_all_action.setShortcutContext(Qt.ApplicationShortcut)
        select_all_action.triggered.connect(lambda: self._edit_action("selectAll"))
        edit_menu.addAction(select_all_action)

        # run menu
        run_menu = menu_bar.addMenu("&Run")

        run_action = QAction("Run File", self)
        self._run_action = run_action
        run_action.setShortcut(QKeySequence("Ctrl+R"))
        run_action.triggered.connect(self.run_file)
        run_menu.addAction(run_action)

        self._stop_running_action = QAction("Stop Running", self)
        self._stop_running_action.setShortcut(QKeySequence("Ctrl+."))
        self._stop_running_action.setEnabled(False)
        self._stop_running_action.triggered.connect(self.stop_running)
        run_menu.addAction(self._stop_running_action)
        self._update_run_controls()

        # view menu
        view_menu = menu_bar.addMenu("&View")

        show_explorer_action = QAction("Show Explorer", self)
        show_explorer_action.triggered.connect(self._show_explorer)
        view_menu.addAction(show_explorer_action)

        show_output_action = QAction("Show Output", self)
        show_output_action.triggered.connect(lambda: self._show_bottom_panel("output"))
        view_menu.addAction(show_output_action)

        show_terminal_action = QAction("Show Terminal", self)
        show_terminal_action.setShortcut(QKeySequence("Ctrl+T"))
        show_terminal_action.triggered.connect(lambda: self._show_bottom_panel("terminal"))
        view_menu.addAction(show_terminal_action)

        # action to show/hide commands list in explorer
        show_commands_list_action = QAction("Show Key Shortcuts", self)
        show_commands_list_action.setCheckable(True)
        self._show_commands_list_action = show_commands_list_action
        settings = QSettings(SETTINGS_ORGANIZATION, APP_NAME)
        show_commands = settings.value("show_key_shortcuts", True, type=bool)
        if self.explorer._commands_section.isHidden() == show_commands:
            self.explorer._toggle_commands_section()
        show_commands_list_action.setChecked(show_commands)
        show_commands_list_action.triggered.connect(self._set_key_shortcuts_visible)

        # keep action in sync when explorer toggles it using the header button
        try:
            self.explorer.commands_visibility_changed.connect(self._set_key_shortcuts_visible)
        except Exception:
            pass

        view_menu.addAction(show_commands_list_action)

        restore_layout_action = QAction("Restore Layout", self)
        restore_layout_action.triggered.connect(self._restore_default_layout)
        restore_layout_action.setShortcut(QKeySequence("Ctrl+0"))
        view_menu.addAction(restore_layout_action)

        # for loop for pointing hand cursor
        # for items in (
        #     new_action,
        #     open_action,
        #     open_folder_action,
        #     close_project_action,
        #     save_action,
        #     save_as_action,
        #     exit_action,
        # ):
        #     # common QAction settings here: for future use
        #     items.setCursor(Qt.PointingHandCursor)

        # termnal layout
        terminal_menu = menu_bar.addMenu("&Terminal")

        focus_terminal_action = QAction("Focus Terminal", self)
        focus_terminal_action.triggered.connect(self._focus_terminal)
        terminal_menu.addAction(focus_terminal_action)

        # line numbers
        line_numbers_menu = menu_bar.addMenu("&Line Numbers")
        line_number_group = QActionGroup(self)
        line_number_group.setExclusive(True)

        increment_line_number_action = QAction("Absolute Line Numbers (Default)", self)
        increment_line_number_action.setCheckable(True)
        increment_line_number_action.triggered.connect(
            lambda: self._set_line_number_mode("absolute")
        )
        line_number_group.addAction(increment_line_number_action)
        line_numbers_menu.addAction(increment_line_number_action)

        relative_line_numbers_action = QAction("Relative Line Numbers (Advanced)", self)
        relative_line_numbers_action.setCheckable(True)
        relative_line_numbers_action.triggered.connect(
            lambda: self._set_line_number_mode("relative")
        )
        line_number_group.addAction(relative_line_numbers_action)
        line_numbers_menu.addAction(relative_line_numbers_action)

        hybrid_line_numbers_action = QAction("Hybrid Line Numbers (Neovim)", self)
        hybrid_line_numbers_action.setCheckable(True)
        hybrid_line_numbers_action.triggered.connect(
            lambda: self._set_line_number_mode("hybrid")
        )
        line_number_group.addAction(hybrid_line_numbers_action)
        line_numbers_menu.addAction(hybrid_line_numbers_action)

        self._line_number_actions = {
            "absolute": increment_line_number_action,
            "relative": relative_line_numbers_action,
            "hybrid": hybrid_line_numbers_action,
        }
        saved_line_number_mode = QSettings(
            SETTINGS_ORGANIZATION, APP_NAME
        ).value("line_number_mode", "absolute")
        if saved_line_number_mode not in self._line_number_actions:
            saved_line_number_mode = "absolute"
        self._set_line_number_mode(saved_line_number_mode, persist=False)

        """ # Git actions (Feature 9): interactive push which may prompt for credentials
        git_menu = menu_bar.addMenu("&Git")

        git_push_action = QAction("Push (git)", self)
        git_push_action.setShortcut(QKeySequence("Ctrl+Shift+P"))
        git_push_action.triggered.connect(self._git_push)
        git_menu.addAction(git_push_action) """

        # help menu / updater
        help_menu = menu_bar.addMenu("&Help")

        update_action = QAction("Update Lau-PyDE", self)
        update_action.setShortcut(QKeySequence("Ctrl+U"))
        update_action.triggered.connect(self._update_lau_pyde)
        help_menu.addAction(update_action)

        # populate explorer commands now that menus/actions exist
        try:
            if hasattr(self.explorer, 'populate_commands'):
                self.explorer.populate_commands(self)
        except Exception:
            pass

    def _edit_action(self, operation: str) -> None:
        widget = self.focusWidget()
        while widget is not None:
            method = getattr(widget, operation, None)
            if callable(method):
                if operation == "copy" and hasattr(widget, "textCursor"):
                    selection = QTextCursor(widget.textCursor())
                    method()
                    widget.setTextCursor(selection)
                else:
                    method()
                return
            widget = widget.parentWidget()
        getattr(self.editor, operation)()

    # file operations
    def _project_root(self) -> Path:
        return Path.home() / "Lau-PyDE_Projects"

    def _ensure_project_root(self) -> bool:
        root = self._project_root()

        if root.exists():
            return True

        if self._project_root_permission_granted:
            try:
                root.mkdir(parents=True, exist_ok=True)
                return True
            except OSError as error:
                QMessageBox.critical(
                    self,
                    APP_NAME,
                    f"Lau-PyDE cannot create the project folder at:\n{root}\n\n{error}\n\nPlease choose a different writable location.",
                )
                return False

        choice = QMessageBox.question(
            self,
            APP_NAME,
            f"Lau-PyDE wants to create a project folder in your home directory:\n{root}\n\nAllow it?",
            QMessageBox.Yes | QMessageBox.No,
        )

        if choice != QMessageBox.Yes:
            folder = QFileDialog.getExistingDirectory(
                self,
                "Choose a writable project folder",
                str(Path.home()),
            )
            if not folder:
                return False
            self._current_folder = folder
            self._refresh_file_tab_labels()
            self.explorer.set_root_folder(folder)
            self.terminal_panel.set_working_directory(folder)
            return True

        try:
            root.mkdir(parents=True, exist_ok=True)
            self._project_root_permission_granted = True
            return True
        except OSError as error:
            QMessageBox.critical(
                self,
                APP_NAME,
                f"Permission denied while creating the project folder:\n{root}\n\n{error}\n\nPlease choose a different writable location.",
            )
            return False

    def new_file(self) -> None:
        default_dir = Path(self._current_folder) if self._current_folder else Path.home()
        if not default_dir.exists():
            default_dir = Path.home()

        file_name, ok = QInputDialog.getText(
            self,
            "New File",
            "File name (include extension):",
            text="untitled.py",
        )

        if not ok:
            return

        clean_name = (file_name or "untitled.py").strip()
        if not clean_name:
            clean_name = "untitled.py"
        if not Path(clean_name).suffix:
            clean_name = f"{clean_name}.py"

        target_path = default_dir / clean_name
        if target_path.exists():
            QMessageBox.warning(
                self,
                APP_NAME,
                f"A file named '{clean_name}' already exists at:\n{target_path}",
            )
            return

        try:
            target_path.parent.mkdir(parents=True, exist_ok=True)
            target_path.write_text("", encoding="utf-8")
        except OSError as error:
            QMessageBox.critical(
                self,
                APP_NAME,
                f"Could not create file:\n{target_path}\n\n{error}",
            )
            return

        self.open_file(str(target_path))
        self.statusBar().showMessage(f"New file: {target_path}")

    def new_folder(self) -> None:
        """Create a project folder in the home-directory Lau-PyDE_Projects root."""
        if not self._ensure_project_root():
            return

        root = self._project_root()
        project_name, ok = QInputDialog.getText(
            self,
            "New Project Folder",
            "Project name:",
            text="",
        )

        if not ok or not project_name.strip():
            return

        clean_name = project_name.strip().strip("/\\")
        if not clean_name:
            return

        folder = root / clean_name
        if folder.exists():
            QMessageBox.warning(
                self,
                APP_NAME,
                f"A project folder named '{clean_name}' already exists at:\n{folder}",
            )
            return

        try:
            folder.mkdir(parents=True, exist_ok=False)
        except OSError as error:
            QMessageBox.critical(
                self,
                APP_NAME,
                f"Could not create project folder:\n{folder}\n\n{error}",
            )
            return

        self._current_folder = str(folder)
        self._refresh_file_tab_labels()
        self.explorer.set_root_folder(str(folder))
        self.terminal_panel.set_working_directory(str(folder))
        RECENT_PROJECT_FILE.write_text(json.dumps({"project": str(folder)}))

        create_file_choice = QMessageBox.question(
            self,
            APP_NAME,
            f"Project folder created at:\n{folder}\n\nCreate a starter .py file in it now?",
            QMessageBox.Yes | QMessageBox.No,
        )

        if create_file_choice == QMessageBox.Yes:
            starter_name, starter_ok = QInputDialog.getText(
                self,
                "Starter Python File",
                "File name (.py):",
                text="main.py",
            )
            if starter_ok:
                file_name = (starter_name or "main.py").strip()
                if not file_name:
                    file_name = "main.py"
                if not file_name.endswith(".py"):
                    file_name = f"{file_name}.py"
                file_path = folder / file_name
                try:
                    file_path.write_text("", encoding="utf-8")
                except OSError as error:
                    QMessageBox.critical(
                        self,
                        APP_NAME,
                        f"Could not create starter file:\n{file_path}\n\n{error}",
                    )
                    return
                self.open_file(str(file_path))
                self.statusBar().showMessage(f"Project folder opened: {folder}")
                return

        self._show_editor()
        self._update_title()
        self.statusBar().showMessage(f"Project folder opened: {folder}")

    def open_file_dialog(self) -> None:
        start_dir = self._current_folder or str(Path.home())
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Open File",
            start_dir,
            "Supported Files (*.py *.txt *.html *.htm *.css *.js *.mjs *.cjs *.md *.json *.yaml *.yml *.cfg *.toml *.c *.h *.cc *.cpp *.cxx *.hpp *.hh *.java *.go *.rs);;All Files (*)",
        )
        if path:
            self.open_file(path)

    def open_file(self, path: str) -> None:
        """Open a specific file path in the editor. Used both by the
        Open dialog and by double-clicking a file in the explorer."""
        path = str(Path(path).expanduser().resolve())
        if path == self._current_file_path:
            self._record_recent_file(path)
            self._show_editor()
            return

        try:
            read_file(path)
        except OSError as error:
            QMessageBox.critical(self, APP_NAME, f"Could not open file:\n{path}\n\n{error}")
            return

        if (self._current_file_path or self.editor.document().isModified()) and not self.save_file():
            return

        existing_index = next(
            (
                index
                for index in range(self._file_tab_bar.count())
                if self._file_tab_bar.tabData(index) == path
            ),
            -1,
        )
        if existing_index >= 0:
            self._file_tab_bar.setCurrentIndex(existing_index)
        else:
            tab_index = self._file_tab_bar.addTab(
                self._file_icon_provider.icon_from_path(path),
                self._file_tab_label(path),
            )
            self._file_tab_bar.setTabData(tab_index, path)
            self._file_tab_bar.setTabToolTip(tab_index, path)
            close_button = QToolButton(self._file_tab_bar)
            close_button.setIcon(
                QIcon(str(Path(__file__).resolve().parent.parent / "assets" / "icons" / "file-close.svg"))
            )
            close_button.setIconSize(QSize(12, 12))
            close_button.setFixedSize(18, 18)
            close_button.setAutoRaise(True)
            close_button.setToolTip("Close file")
            close_button.clicked.connect(
                lambda _checked=False, file_path=path: self._close_file_tab_path(file_path)
            )
            self._file_tab_bar.setTabButton(tab_index, QTabBar.RightSide, close_button)
            self._file_tab_bar.setCurrentIndex(tab_index)
            self._on_file_tab_changed(tab_index)
        self._file_tab_bar.show()
        self._show_editor()

        # reveal the file in the explorer tree
        try:
            if hasattr(self, 'explorer'):
                self.explorer.reveal_path(path)
        except Exception:
            pass

        if self._current_folder:
            RECENT_PROJECT_FILE.write_text(
                json.dumps(
                    {
                        "project": self._current_folder,
                        "file": path,
                    }
                )
            )

        self._update_title()
        self.statusBar().showMessage(f"Opened {path}")
        self._record_recent_file(path)

    def _on_file_tab_changed(self, index: int) -> None:
        if index < 0:
            return
        path = self._file_tab_bar.tabData(index)
        if not path or path == self._current_file_path:
            return

        previous_path = self._current_file_path
        if (previous_path or self.editor.document().isModified()) and not self.save_file():
            previous_index = next(
                (
                    tab_index
                    for tab_index in range(self._file_tab_bar.count())
                    if self._file_tab_bar.tabData(tab_index) == previous_path
                ),
                -1,
            )
            if previous_index >= 0:
                self._file_tab_bar.setCurrentIndex(previous_index)
            return

        try:
            content = read_file(path)
        except OSError as error:
            QMessageBox.critical(self, APP_NAME, f"Could not open file:\n{path}\n\n{error}")
            if previous_path:
                previous_index = next(
                    tab_index
                    for tab_index in range(self._file_tab_bar.count())
                    if self._file_tab_bar.tabData(tab_index) == previous_path
                )
                self._file_tab_bar.setCurrentIndex(previous_index)
            return

        self._current_file_path = path
        self.editor.set_file_path(path)
        self.editor.setPlainText(content)
        self.editor.document().setModified(False)
        self._refresh_markdown_preview()
        self._show_editor()
        try:
            self.explorer.reveal_path(path)
        except Exception:
            pass
        if self._current_folder:
            RECENT_PROJECT_FILE.write_text(
                json.dumps({"project": self._current_folder, "file": path})
            )
        self._update_title()
        self.statusBar().showMessage(f"Opened {path}")
        self._record_recent_file(path)

    def _file_tab_label(self, path: str) -> str:
        file_path = Path(path).resolve()
        if self._current_folder:
            try:
                file_path.relative_to(Path(self._current_folder).resolve())
            except ValueError:
                return str(file_path)
        return file_path.name

    def _refresh_file_tab_labels(self) -> None:
        for index in range(self._file_tab_bar.count()):
            path = self._file_tab_bar.tabData(index)
            if path:
                self._file_tab_bar.setTabText(index, self._file_tab_label(path))

    def _close_file_tab(self, index: int) -> None:
        closing_path = self._file_tab_bar.tabData(index)
        if closing_path == self._current_file_path and self.editor.document().isModified():
            if not self.save_file():
                return
        self._file_tab_bar.removeTab(index)
        if self._file_tab_bar.count() == 0:
            self._current_file_path = None
            self.editor.set_file_path(None)
            self.editor.clear()
            self._file_tab_bar.hide()
            self._refresh_markdown_preview()
            self._show_welcome()
            self._update_title()

    def _close_file_tab_path(self, path: str) -> None:
        for index in range(self._file_tab_bar.count()):
            if self._file_tab_bar.tabData(index) == path:
                self._close_file_tab(index)
                return

    def _toggle_markdown_preview(self) -> None:
        if self._editor_content.currentWidget() is self.editor:
            self._editor_content.setCurrentWidget(self._markdown_preview)
            self._markdown_preview_button.setText("Editor")
        else:
            self._editor_content.setCurrentWidget(self.editor)
            self._markdown_preview_button.setText("Preview")

    def _refresh_markdown_preview(self, *_args) -> None:
        if not hasattr(self, "_editor_content"):
            return
        is_markdown = bool(
            self._current_file_path
            and Path(self._current_file_path).suffix.lower() == ".md"
        )
        self._markdown_preview_button.setVisible(is_markdown)
        if not is_markdown:
            self._editor_content.setCurrentWidget(self.editor)
            self._markdown_preview_button.setText("Preview")
        if is_markdown:
            self._markdown_preview.set_markdown_source(
                self.editor.toPlainText(), self._current_file_path
            )

    def open_folder_dialog(self) -> None:
        start_dir = self._current_folder or str(Path.home())
        folder = QFileDialog.getExistingDirectory(self, "Open Folder", start_dir)

        if folder:
            self.open_folder_path(folder)

    def open_folder_path(self, folder: str) -> bool:
        folder_path = Path(folder).expanduser().resolve()
        if not folder_path.is_dir():
            return False
        folder = str(folder_path)
        if folder == self._current_folder:
            return True
        if self.editor.document().isModified() and not self.save_file():
            return False

        self._current_folder = folder
        self._refresh_file_tab_labels()
        self.explorer.set_root_folder(folder)
        settings = QSettings(SETTINGS_ORGANIZATION, APP_NAME)
        show_key_shortcuts = settings.value("show_key_shortcuts", True, type=bool)
        self._set_key_shortcuts_visible(show_key_shortcuts)
        self.explorer.show()
        self.terminal_panel.set_working_directory(folder)
        RECENT_PROJECT_FILE.write_text(json.dumps({"project": folder}))
        self._show_editor()
        self.statusBar().showMessage(f"Workspace: {folder}")
        return True

    def _enable_folder_drop_targets(self) -> None:
        self.setAcceptDrops(True)
        for widget in self.findChildren(QWidget):
            widget.setAcceptDrops(True)
            widget.installEventFilter(self)

    def _dropped_folder(self, event) -> str | None:
        mime_data = event.mimeData()
        if not mime_data.hasUrls():
            return None
        for url in mime_data.urls():
            if not url.isLocalFile():
                continue
            path = Path(url.toLocalFile()).expanduser()
            if path.is_dir():
                return str(path.resolve())
        return None

    def eventFilter(self, watched, event) -> bool:
        if event.type() in (QEvent.DragEnter, QEvent.DragMove, QEvent.Drop):
            folder = self._dropped_folder(event)
            if folder:
                if event.type() == QEvent.Drop:
                    if self.open_folder_path(folder):
                        event.acceptProposedAction()
                    else:
                        event.ignore()
                else:
                    event.acceptProposedAction()
                return True
            if event.type() in (QEvent.DragEnter, QEvent.DragMove):
                event.ignore()
                return True
        return super().eventFilter(watched, event)

    def dragEnterEvent(self, event) -> None:
        if self._dropped_folder(event):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event) -> None:
        self.dragEnterEvent(event)

    def dropEvent(self, event) -> None:
        folder = self._dropped_folder(event)
        if folder and self.open_folder_path(folder):
            event.acceptProposedAction()
        else:
            event.ignore()

    def close_project(self) -> None:
        """Close the current project workspace."""
        self._file_tab_bar.blockSignals(True)
        while self._file_tab_bar.count():
            self._file_tab_bar.removeTab(0)
        self._file_tab_bar.blockSignals(False)
        self._file_tab_bar.hide()
        self._current_folder = None
        self._current_file_path = None
        self.editor.set_file_path(None)
        self._refresh_markdown_preview()

        # remove the current project folder from the IDE and set to None
        self.explorer.set_root_folder(None)
        self.terminal_panel.set_working_directory(str(Path.home()))

        if RECENT_PROJECT_FILE.exists():
            try:
                RECENT_PROJECT_FILE.unlink()
            except OSError:
                pass

        self._show_welcome()
        self.editor.clear()
        self.explorer.hide()

        self._update_title()
        self.statusBar().showMessage("Project closed")

    def save_file(self) -> bool:
        """Save to the current file path, prompting for one if there isn't one yet.
        Returns True if the file ended up saved, False if the user cancelled."""
        if self._current_file_path is None:
            return self.save_file_as()

        try:
            write_file(self._current_file_path, self.editor.toPlainText())
        except OSError as error:
            QMessageBox.critical(
                self, APP_NAME, f"Could not save file:\n{self._current_file_path}\n\n{error}"
            )
            return False

        self.editor.set_file_path(self._current_file_path)
        self.editor.document().setModified(False)
        self._update_title()
        self.statusBar().showMessage(f"Saved {self._current_file_path}")
        return True

    def load_recent_project(self) -> None:
        if not RECENT_PROJECT_FILE.exists():
            return
        try:
            data = json.loads(RECENT_PROJECT_FILE.read_text())
            folder = data.get("project")

            if folder and Path(folder).is_dir():
                folder = str(Path(folder).expanduser().resolve())
                self._current_folder = folder
                self._refresh_file_tab_labels()
                self.terminal_panel.set_working_directory(folder)
                # Keep the Explorer rooted at the selected workspace folder.
                self.explorer.set_root_folder(folder)
                try:
                    # ensure commands section is visible and layout is restored
                    try:
                        self.explorer._commands_section.show()
                    except Exception:
                        pass
                except Exception:
                    pass
                try:
                    self.explorer.show()
                except Exception:
                    pass

                file_path = data.get("file")

                if file_path and Path(file_path).is_file():
                    self.open_file(file_path)
            elif folder:
                # Clear stale persistence when the project was moved or
                # deleted; the next Open Folder action can then proceed
                # normally.
                try:
                    RECENT_PROJECT_FILE.unlink()
                except OSError:
                    pass
                self.statusBar().showMessage(
                    f"Project folder no longer exists: {folder}"
                )
                
        except (json.JSONDecodeError, OSError):
            pass

    def save_file_as(self) -> bool:
        start_dir = self._current_folder or str(Path.home())
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save As",
            start_dir,
            "Supported Files (*.py *.txt *.html *.htm *.css *.js *.mjs *.cjs *.md *.json *.yaml *.yml *.cfg *.toml *.c *.h *.cc *.cpp *.cxx *.hpp *.hh *.java *.go *.rs);;All Files (*)",
        )
        if not path:
            return False
        self._current_file_path = path
        self.editor.set_file_path(path)
        self._refresh_markdown_preview()
        return self.save_file()

    def _confirm_discard_changes(self) -> bool:
        """If there are unsaved changes, ask what to do.
        Returns True if it's OK to proceed, False to cancel the action."""
        if not self.editor.document().isModified():
            return True

        choice = QMessageBox.question(
            self,
            APP_NAME,
            "This file has unsaved changes. Save before continuing?",
            QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel,
        )
        if choice == QMessageBox.Save:
            return self.save_file()
        return choice == QMessageBox.Discard

    # run
    def run_file(self) -> None:
        if self._runner.is_running():
            QMessageBox.information(self, APP_NAME, "A program is already running.")
            return

        if self._current_file_path and Path(self._current_file_path).suffix.lower() != ".py":
            QMessageBox.information(self, APP_NAME, "Only Python files can be run in Lau-PyDE.")
            return

        # the file has to exist on disk before we can run it as a file,
        # so save first (prompting for a location if it's a new file).
        if self._current_file_path is None or self.editor.document().isModified():
            if not self.save_file():
                return  # user cancelled the save

        if not self._current_file_path or Path(self._current_file_path).suffix.lower() != ".py":
            QMessageBox.information(self, APP_NAME, "Only Python files can be run in Lau-PyDE.")
            self._update_run_controls()
            return

        working_dir = self._current_folder or str(Path(self._current_file_path).parent)

        self.editor._check_errors()

        error_messages = self.editor.get_error_messages()

        if self._current_file_path:
            self.explorer.set_error_count(
                self._current_file_path,
                len(error_messages),
            )

        if error_messages:
            self._output_line_tail = ""

            self.output_panel.clear()
            self.output_panel.stop_input()

            self._show_bottom_panel("output")

            project_name = Path.cwd()

            issue_count = len(error_messages)
            issue_label = "problem" if issue_count == 1 else "problems"

            self._append_error_output(
                f"Code Issues  ({issue_count} {issue_label})\n"
            )

            self._append_error_output(
                f"Project Path: {project_name}\n\n"
            )

            for message in error_messages:
                self._append_error_output(f"• {message}\n")

            self._set_running_controls(False)
            self.statusBar().showMessage("status: ready")

            return

        # self._output_line_tail = ""
        # self.output_panel.clear()
        # self.output_panel.setPlainText("")
        # self.output_panel.stop_input()
        # self._show_bottom_panel("output")
        # self._append_output(f"Running at {self._current_file_path}\n")

        self._output_line_tail = ""

        self.output_panel.clear()
        self.output_panel.setPlainText("")
        self.output_panel.stop_input()

        self._show_bottom_panel("output")

        cursor = self.output_panel.textCursor()
        cursor.movePosition(QTextCursor.Start)
        self.output_panel.setTextCursor(cursor)

        self._append_output(f"Running at {self._current_file_path}\n")

        self._runner.run_file(self._current_file_path, working_dir)
        self._set_running_controls(True)
        self.statusBar().showMessage("status: running")

    def _run_or_stop(self) -> None:
        if self._runner.is_running():
            self.stop_running()
        else:
            self.run_file()

    def stop_running(self) -> None:
        """Kill the program currently being run from the editor."""
        if not self._runner.is_running():
            return

        self.output_panel.stop_input()
        self._active_prompt = ""
        self._runner.stop()
        self._append_output("\n\nCode stop running successfully.")
        self.statusBar().showMessage("Killed")

    def _set_running_controls(self, running: bool) -> None:
        self._update_run_controls(running)
        self._stop_running_action.setEnabled(running)

    def _update_run_controls(self, running: bool | None = None) -> None:
        if running is None:
            running = self._runner.is_running() if hasattr(self, "_runner") else False
        can_run = (
            self._current_file_path is None
            or Path(self._current_file_path).suffix.lower() == ".py"
        )
        if hasattr(self, "_stop_running_button"):
            self._stop_running_button.setEnabled(running or can_run)
            self._stop_running_button.setIcon(panel_icon("stop" if running else "play"))
            self._stop_running_button.setToolTip(
                "Stop the running Python program" if running
                else "Run the current Python file" if can_run
                else "Only Python files can be run"
            )
        if hasattr(self, "_run_action"):
            self._run_action.setEnabled(not running and can_run)
            self._run_action.setToolTip(
                "Run the current Python file" if can_run
                else "Only Python files can be run"
            )
        if hasattr(self, "_stop_running_action"):
            self._stop_running_action.setEnabled(running)
    def _append_error_output(self, text: str) -> None:
        self.output_panel.moveCursor(QTextCursor.End)
        cursor = self.output_panel.textCursor()
        cursor.movePosition(QTextCursor.End)
        error_format = QTextCharFormat()
        error_format.setForeground(QColor("#ff6b6b"))
        cursor.insertText(text, error_format)
        self.output_panel.setTextCursor(cursor)
    def _append_output(self, text: str) -> None:
        self.output_panel.moveCursor(QTextCursor.End)
        cursor = self.output_panel.textCursor()
        cursor.movePosition(QTextCursor.End)

        error_pattern = re.compile(
            r"(Traceback \(most recent call last\):|File \".*\"|\b(?:SyntaxError|NameError|ValueError|TypeError|IndexError|KeyError|AttributeError|IndentationError|TabError|AssertionError|RuntimeError|ModuleNotFoundError|ImportError)\b|Error:|Exception:)",
            re.IGNORECASE,
        )
        output_format = QTextCharFormat()
        output_format.setForeground(
            QColor("#ff0000") if error_pattern.search(text) else QColor("#00ff00")
        )
        cursor.insertText(text, output_format)
        self.output_panel.setTextCursor(cursor)

        # keep the unfinished line so a prompt split across process output
        # chunks (for example, "Enter your" + " name: ") is still detected.
        self._output_line_tail = (self._output_line_tail + text).rsplit("\n", 1)[-1]

        if not text or self._runner is None or not self._runner.is_running():
            return

        last_line = self._output_line_tail.rstrip()
        if not last_line:
            return

        prompt = last_line.strip()
        if prompt.endswith(":") or prompt.endswith("?") or prompt.endswith(">"):
            if prompt != self._active_prompt:
                self._active_prompt = prompt
                self.output_panel.start_input()

    def _on_run_finished(self, exit_code: int) -> None:
        self._active_prompt = ""
        self._output_line_tail = ""
        self.output_panel.stop_input()

        # Auto-save the editor buffer after code execution so the current file is
        # always persisted without a startup restore prompt.
        if self._current_file_path and self.editor.document().isModified():
            try:
                self.save_file()
            except Exception:
                pass

        self._append_output(f"\nProcess finished with exit code {exit_code}. Thank You for using Lau-PyDE!\n")
        self._set_running_controls(False)
        self.statusBar().showMessage("status: ready")

    # pane layout
    def _minimize_bottom_panel(self) -> None:
        self._bottom_minimized = True
        self._restore_layout()
        self.statusBar().showMessage("Output and terminal minimized. Use View to show them.")

    def _minimize_explorer(self) -> None:
        self._explorer_minimized = True
        self._restore_layout()
        self.statusBar().showMessage("Explorer minimized. Use View to show it.")

    def _maximize_pane(self, pane: str) -> None:
        if self._maximized_pane == pane:
            self._restore_layout()
            return

        if pane == "explorer":
            self._explorer_minimized = False
        else:
            self._bottom_minimized = False

        self._restore_layout()
        self._maximized_pane = pane
        self._bottom_tabs.tabBar().hide()

        if pane == "explorer":
            self.explorer.show()
            self._editor_and_output.hide()
            self._main_splitter.setSizes([self.width(), 0])
        else:
            self.explorer.hide()
            self._editor_container.hide()
            self._bottom_tabs.show()
            self._bottom_tabs.setCurrentWidget(
                self._output_container if pane == "output" else self.terminal_panel
            )
            self._editor_and_output.setSizes([0, self.height()])
            self._main_splitter.setSizes([0, self.width()])
            if pane == "terminal":
                self.terminal_panel.focus_input()

    def _restore_default_layout(self) -> None:
        """Restore every user-collapsible panel to the default layout."""
        self._explorer_minimized = False
        self._bottom_minimized = False
        self._maximized_pane = None
        self._restore_layout()
        if self._current_folder or self._current_file_path:
            self.explorer.show()
        try:
            self.explorer.restore_commands_section()
        except AttributeError:
            pass

    def _restore_layout(self) -> None:
        self._maximized_pane = None

        self._main_splitter.show()
        self._editor_stack.show()
        welcome_active = not (self._current_folder or self._current_file_path)
        if not welcome_active:
            self._editor_stack.setCurrentWidget(self._editor_container)
        else:
            self._editor_stack.setCurrentWidget(self._welcome_widget)
        self._editor_container.show()
        self.editor.show()
        # ensure the active editor-output splitter is in the main splitter
        # and visible. Default active splitter is vertical (bottom output).
        try:
            # replace the widget in main splitter if needed
            right_index = 1
            if self._main_splitter.widget(right_index) is not self._editor_and_output:
                # remove existing and insert the active splitter
                self._main_splitter.replaceWidget(right_index, self._editor_and_output)
        except Exception:
            pass
        self._editor_and_output.show()
        self._editor_and_output.setVisible(True)

        self.explorer.setVisible(not welcome_active and not self._explorer_minimized)
        # Respect the minimized flag; `setVisible` controls whether
        # the explorer is shown. Do not force-show here.

        self._bottom_tabs.show()
        self._bottom_tabs.setVisible(not welcome_active and not self._bottom_minimized)
        self._bottom_tabs.tabBar().show()

        if welcome_active:
            self._main_splitter.setSizes([0, max(1, self.width())])
        else:
            self._main_splitter.setSizes([220, max(1, self.width() - 220)])

        if welcome_active:
            self._editor_and_output.setSizes([max(1, self.height()), 0])
        elif not self._bottom_minimized:
            # when not minimized, sizing depends on orientation
            if self._output_orientation == "horizontal":
                # vertical splitter: editor height larger than bottom panel
                if self._editor_and_output.orientation() == Qt.Vertical:
                    self._editor_and_output.setSizes([max(1, self.height() - 260), 260])
                else:
                    # fallback: ensure reasonable sizes
                    self._editor_and_output.setSizes([max(1, self.width() - 360), 360])
            else:
                # vertical (right) mode: set horizontal splitter sizes
                if self._editor_and_output.orientation() == Qt.Horizontal:
                    self._editor_and_output.setSizes([max(1, self.width() - 360), 360])
                else:
                    self._editor_and_output.setSizes([max(1, self.height() - 260), 260])
        else:
            if self._output_orientation == "horizontal":
                if self._editor_and_output.orientation() == Qt.Vertical:
                    self._editor_and_output.setSizes([max(1, self.height() - 40), 40])
                else:
                    self._editor_and_output.setSizes([max(1, self.width() - 80), 80])
            else:
                if self._editor_and_output.orientation() == Qt.Horizontal:
                    self._editor_and_output.setSizes([max(1, self.width() - 80), 80])
                else:
                    self._editor_and_output.setSizes([max(1, self.height() - 40), 40])

    def _show_explorer(self) -> None:
        self._restore_layout()
        self._explorer_minimized = False
        self.explorer.show()

    def _toggle_output_orientation(self) -> None:
        """Toggle output area orientation between bottom (horizontal) and right (vertical)."""
        old = self._output_orientation
        new = "vertical" if old == "horizontal" else "horizontal"
        self._output_orientation = new

        # update icon and tooltip
        if new == "vertical":
            self._output_orientation_button.setIcon(panel_icon("orient-left"))
            self._output_orientation_button.setToolTip("Move output to bottom")
            # switch splitter orientation to horizontal (editor left, output right)
            try:
                self._editor_and_output.setOrientation(Qt.Horizontal)
            except Exception:
                pass
        else:
            self._output_orientation_button.setIcon(panel_icon("orient-right"))
            self._output_orientation_button.setToolTip("Move output to the right")
            # switch splitter orientation to vertical (editor top, output bottom)
            try:
                self._editor_and_output.setOrientation(Qt.Vertical)
            except Exception:
                pass

        # replace the widget in the main splitter and restore layout
        try:
            self._restore_layout()
        except Exception:
            pass

    # shwow welcome message method
    def _show_welcome(self) -> None:
         self._refresh_welcome_recent_files()
         self._editor_stack.setCurrentWidget(self._welcome_widget)
         if hasattr(self, "_main_splitter"):
             self._restore_layout()

    def _show_editor(self) -> None:
        self._editor_stack.setCurrentWidget(self._editor_container)
        if hasattr(self, "_main_splitter"):
            self._restore_layout()

    def _maybe_autosave(self) -> None:
        if not self.editor.document().isModified():
            return
        try:
            write_recovery(self._current_file_path, self.editor.toPlainText())
        except Exception:
            pass

    def _schedule_autosave(self) -> None:
        if self.editor.document().isModified():
            self._autosave_debounce_timer.start()

    def _autosave_current_file(self) -> None:
        if not self.editor.document().isModified():
            return
        content = self.editor.toPlainText()
        if not self._current_file_path:
            return
        try:
            write_file(self._current_file_path, content)
        except OSError as error:
            self.statusBar().showMessage(f"Autosave failed: {error}")
            return
        self.editor.document().setModified(False)
        self._update_title()
        self.statusBar().showMessage(f"Autosaved {self._current_file_path}", 2000)

    def _git_push(self) -> None:
        """Run `git push` in the current project folder using the terminal.

        This opens the terminal panel and runs `git push`. The terminal is
        already wired to allow interactive stdin so credential prompts will
        be handled by the inline terminal input.
        """
        folder = self._current_folder or (Path(self._current_file_path).parent if self._current_file_path else None)
        if not folder:
            QMessageBox.information(self, APP_NAME, "Open a project folder or file first to run git push.")
            return

        self._show_bottom_panel("terminal")
        try:
            # ensure terminal working directory and start the command
            self.terminal_panel.set_working_directory(str(folder))
            # start git push; the TerminalPanel will run bash -c 'git push'
            self.terminal_panel._run_command("git push")
        except Exception as e:
            QMessageBox.critical(self, APP_NAME, f"Could not start git push:\n{e}")

    def _startup_update_check(self) -> None:
        settings = QSettings(SETTINGS_ORGANIZATION, APP_NAME)
        last_check = float(settings.value("last_update_check", 0) or 0)
        if time.time() - last_check < 24 * 60 * 60:
            return
        settings.setValue("last_update_check", time.time())
        self._check_for_updates(manual=False)

    def _update_lau_pyde(self) -> None:
        self._check_for_updates(manual=True)

    def _check_for_updates(self, manual: bool = False) -> None:
        if self._update_thread is not None and self._update_thread.isRunning():
            if manual:
                self.statusBar().showMessage("Already checking for updates...")
            return
        self._update_thread = QThread(self)
        self._update_worker = UpdateWorker()
        self._update_manual = manual
        self._update_worker.moveToThread(self._update_thread)
        self._update_thread.started.connect(self._update_worker.run)
        self._update_worker.finished.connect(self._update_result_from_worker)
        self._update_worker.failed.connect(self._update_failed_from_worker)
        self._update_worker.finished.connect(self._update_thread.quit)
        self._update_worker.failed.connect(self._update_thread.quit)
        self._update_thread.finished.connect(self._update_worker.deleteLater)
        self._update_thread.finished.connect(self._update_thread.deleteLater)
        self._update_thread.finished.connect(self._update_finished)
        self._update_thread.start()
        if manual:
            self.statusBar().showMessage("Checking for updates...")

    def _update_finished(self) -> None:
        self._update_thread = None
        self._update_worker = None

    def _open_update_url(self, url: str) -> None:
        target = url or RELEASE_PAGE
        if sys.platform.startswith("linux"):
            try:
                subprocess.Popen(
                    ["xdg-open", target],
                    start_new_session=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            except OSError:
                self.statusBar().showMessage("Could not open the update link")
            return
        QDesktopServices.openUrl(QUrl(target))

    def _update_result_from_worker(self, release) -> None:
        self._update_result(release, self._update_manual)

    def _update_failed_from_worker(self, error: str) -> None:
        self._update_failed(error, self._update_manual)

    def _update_result(self, release, manual: bool) -> None:
        comparison = compare_versions(release.version, APP_VERSION)
        if comparison is None or comparison <= 0:
            if manual:
                QMessageBox.information(self, APP_NAME, f"Lau-PyDE {APP_VERSION} is up to date.")
            return
        if not manual and release.version == self._last_update_version:
            return
        self._last_update_version = release.version
        notes = release.notes[:800] or "No release notes were provided."
        url = select_download_url(release, current_platform())
        dialog = QDialog(self)
        dialog.setWindowTitle("Lau-PyDE update available")
        dialog.setObjectName("updateDialog")
        screen = dialog.screen() or self.screen()
        available = screen.availableGeometry() if screen else None
        width = min(680, max(460, int(available.width() * 0.52))) if available else 560
        height = min(560, max(360, int(available.height() * 0.62))) if available else 460
        dialog.resize(width, height)
        dialog.setMinimumSize(420, 340)
        dialog.setStyleSheet("""
            QDialog#updateDialog { background: #202124; }
            QLabel#updateSummary { color: #e8eaed; font-size: 13px; padding: 2px 4px 6px; }
            QTextBrowser#updateNotes { background: #292a2d; color: #d8dbe0; border: 1px solid #3b3d42; border-radius: 8px; padding: 10px; font-size: 12px; }
            QDialogButtonBox QPushButton { min-width: 116px; padding: 7px 14px; border-radius: 6px; color: #e8eaed; background: #35363a; border: 1px solid #4a4d52; }
            QDialogButtonBox QPushButton:hover { background: #414349; }
            QDialogButtonBox QPushButton:default { background: #1976d2; border-color: #3289df; }
        """)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(18, 16, 18, 14)
        layout.setSpacing(10)
        summary = QLabel(f"Lau-PyDE {release.version} is available  •  installed {APP_VERSION}")
        summary.setObjectName("updateSummary")
        summary.setWordWrap(True)
        layout.addWidget(summary)
        notes_view = QTextBrowser(dialog)
        notes_view.setObjectName("updateNotes")
        notes_view.setOpenExternalLinks(True)
        notes_view.setMarkdown(f"## What’s new in Lau-PyDE {release.version}\n\n{notes}")
        layout.addWidget(notes_view, 1)
        buttons = QDialogButtonBox(dialog)
        download = buttons.addButton("Download Update", QDialogButtonBox.AcceptRole)
        close = buttons.addButton("Close", QDialogButtonBox.RejectRole)
        download.setDefault(True)
        download.clicked.connect(dialog.accept)
        close.clicked.connect(dialog.reject)
        layout.addWidget(buttons)
        result = dialog.exec()
        if result == QDialog.Accepted:
            QTimer.singleShot(0, lambda: self._open_update_url(url))

    def _update_failed(self, _error: str, manual: bool) -> None:
        self.statusBar().showMessage("Update check unavailable")
        if manual:
            QMessageBox.information(self, APP_NAME, "Could not check for updates right now. Please try again later.")

    def _check_startup_recovery(self) -> None:
        """Startup recovery prompts are intentionally disabled.

        Lau-PyDE now auto-saves the current file whenever it is run instead of
        restoring stale recovery files on launch.
        """
        return

    def _show_bottom_panel(self, pane: str) -> None:
        self._restore_layout()
        self._bottom_minimized = False
        self._bottom_tabs.show()
        self._bottom_tabs.setCurrentWidget(
            self._output_container if pane == "output" else self.terminal_panel
        )
        if pane == "terminal":
            self.terminal_panel.focus_input()

    def _focus_terminal(self) -> None:
        self._show_bottom_panel("terminal")

    # misc
    def _on_modification_changed(self, _modified: bool) -> None:
        self._update_title()

    def _update_title(self) -> None:
        name = Path(self._current_file_path).name if self._current_file_path else "Untitled"
        star = "*" if self.editor.document().isModified() else ""

        error_count = 0
        if self._current_file_path is not None:
            self.editor._check_errors()
            error_count = len(self.editor.get_error_messages())

        title = f"{star}{name}"
        if error_count > 0:
            title = f"{title}    {error_count}"

        self._file_label.setText(name)
        self._error_badge.setText(f"{error_count}" if error_count > 0 else "")
        self.setWindowTitle(f"{title} — {APP_NAME}")
        self._update_run_controls()

    def _set_line_number_mode(self, mode: str, persist: bool = True) -> None:
        """Apply the line-number mode and remember it for the next launch."""
        self.editor.set_line_number_mode(mode)
        self._line_number_actions[mode].setChecked(True)
        if persist:
            settings = QSettings(SETTINGS_ORGANIZATION, APP_NAME)
            settings.setValue("line_number_mode", mode)
            settings.sync()

    def closeEvent(self, event) -> None:
        """Called automatically by Qt when the user tries to close the window."""
        if not self._confirm_discard_changes():
            event.ignore()
            return

        if self._runner.is_running():
            choice = QMessageBox.question(
                self,
                APP_NAME,
                "A program is still running. Stop it and quit?",
                QMessageBox.Yes | QMessageBox.No,
            )
            if choice != QMessageBox.Yes:
                event.ignore()
                return
            self._runner.stop()

        # persist current project folder so it is restored on next launch
        try:
            if self._current_folder:
                RECENT_PROJECT_FILE.write_text(json.dumps({"project": self._current_folder}))
        except Exception:
            pass

        event.accept()
